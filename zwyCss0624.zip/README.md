开发中用得上的动画效果

使用方式：

1.在App.vue全局引入common文件夹下的zwyCss.css

`	@import './common/zwyCss.css';`

2.为你想要效果的view添加class  ||  hover-class

`				<view class="btn zwyHover1">按钮</view>`			

`				<view class="btn" hover-class="zwyHover1">按钮</view>`	

在线预览地址：https://zwyboom.gitee.io/zwycss/#/

github地址:https://github.com/seventhcode/zwyCss

欢迎star，你们的star是作者创作的动力~~



![zwyCss](C:\Users\haodi\Desktop\zwyCss\zwyCss.jpg)